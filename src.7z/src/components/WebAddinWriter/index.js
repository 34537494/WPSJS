import React, { Component } from 'react';
import { Route, Switch,Redirect } from 'react-router-dom';
import Navigator from './WriteComponents/navigator/navigator';
import { Layout } from 'antd';
import Two from './WriteComponents/pages/function';
import Three from './WriteComponents/pages/edit';
import Four from './WriteComponents/pages/four';
import Five from './WriteComponents/pages/expand';
import Six from './WriteComponents/pages/merge';
import Seven from './WriteComponents/pages/fillTable';
import eight from './WriteComponents/pages/Repository';
import fillFinanceTable from './WriteComponents/pages/fillFinanceTable';
const { Content } = Layout;

class WriterPane extends Component {
  render() {
    return (
      <div>
        <Layout>
          <Content style={{ padding: '0 ' }}>
            <Layout className="site-layout-background" style={{ padding: ' 0' }}>
              <Navigator />
              <Content style={{ padding: '0 ', minHeight: 1000 ,}}>
                <Switch>
                  <Route path="/writer/function" component={Two} />
                  <Route path="/writer/edit" component={Three} />
                  <Route path="/writer/four" component={Four} />
                  <Route path="/writer/expand" component={Five} />
                  <Route path="/writer/merge" component={Six} />
                  <Route path="/writer/fillTable" component={Seven} />
                  <Route path="/writer/fillFinanceTable" component={fillFinanceTable} />
                  <Route path="/writer/Repository" component={eight} />
                  <Redirect from="/" to="/writer/Repository" />
                </Switch>
              </Content>
            </Layout>
          </Content>
        </Layout>
      </div>
    )
  }
}

export default WriterPane;

/*


const WriterPane = () => (
  <div>
      <Layout>
          <Content style={{ padding: '0 ' }}>
            <Layout className="site-layout-background" style={{ padding: ' 0' }}>
              <Navigator />
              <Content style={{ padding: '0 ', minHeight: 1000 ,}}>
                <Switch>
                  <Route path="/taskpane/function" component={Two} />
                  <Route path="/taskpane/edit" component={Three} />
                  <Route path="/taskpane/four" component={Four} />
                  <Route path="/taskpane/expand" component={Five} />
                  <Route path="/taskpane/merge" component={Six} />
                  <Route path="/taskpane/fillTable" component={Seven} />
                  <Redirect from="/" to="/taskpane/merge" />
                </Switch>
              </Content>
            </Layout>
          </Content>
        </Layout>
  </div>
);

export default WriterPane;

*/