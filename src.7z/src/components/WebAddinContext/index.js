//https://www.jianshu.com/p/da6181ca5564
//https://www.jianshu.com/p/eba2b76b290b
//https://www.jianshu.com/p/87632fc165d0
import {createContext} from "react";

export const {Provider, Consumer} = createContext({
  userid: "",
  tplid: "",
  showLgin:false,
});
