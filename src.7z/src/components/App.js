/* eslint-disable no-useless-escape */
import React from 'react';
import ribbon from './ribbon';
import "./App.scss";
import Loadable from "react-loadable";
import { Provider } from "./WebAddinContext";
import WebAddinSignInOut from "./WebAddinSignInOut";
//import Relogin from "./WebAddinReglogin";
import DialogAlert from "./WebAddinCommon/DynamicModal";
import { HashRouter as Router, Redirect, Route, Switch } from "react-router-dom";
//import { Dialog, DialogType, DialogFooter } from "office-ui-fabric-react/lib/Dialog";
import { apiPublicPath } from "../settings";
import { handlePost, handleFetch } from "./WebAddinCommon";
import { initializeIcons } from "office-ui-fabric-react/lib/Icons";

const md5 = require("js-md5");
const Cookies = require("js-cookie");
initializeIcons(); 
/*
              <Route path="/OtherFun" component={WebAddinOtherFun} />
              <Route path="/UserCenter/:id" component={WebAddinUserCenter} />
              <Route path="/UserCenter" component={WebAddinUserCenter} />
              <Route path="/Helper/:id" component={WebAddinHelper} />
              <Route path="/Helper" component={WebAddinHelper} />
              <Route path="/DemoVideo" component={WebAddinDemoVideo} />
              <Route path="/AboutUs" component={WebAddinAboutUs} />
              <Route path="/Reglogin" component={WebAddinReglogin} />
              <Route path="/FindPsw" component={WebAddinFindPsw} />
*/
const loadingComponent = (props) => {
  if (props.error) {
    return (
      <div align="center" marginTop="50px" marginBotton="50px">
        <h2>
          对不起，加载遇到错误，请刷新界面！<button onClick={props.retry}>刷新</button>
        </h2>
      </div>
    );
  } else if (props.timedOut) {
    return (
      <div align="center" marginTop="50px" marginBotton="50px">
        <h2>
          对不起，加载超时，请刷新界面！ <button onClick={props.retry}>重试</button>
        </h2>
      </div>
    );
  } else if (props.pastDelay) {
    return <p />;
  } else {
    return <p />;
  }
};

const TaskHome = Loadable({
  loader: () => import("./WebAddinTaskPane"),
  loading: loadingComponent,
  delay: 1500,
  timeout: 10000,
});
const WebAddinDemoVideo = Loadable({
  loader: () => import("./WebAddinDemoVideo"),
  loading: loadingComponent,
  delay: 1500,
  timeout: 10000,
});
const WebAddinWriter = Loadable({
  loader: () => import("./WebAddinWriter"),
  loading: loadingComponent,
  delay: 1500,
  timeout: 10000,
});
const WebAddinAboutUs = Loadable({
  loader: () => import("./WebAddinAboutUs"),
  loading: loadingComponent,
  delay: 1500,
  timeout: 10000,
});
const WebAddinCompose = Loadable({
  loader: () => import("./WebAddinCompose"),
  loading: loadingComponent,
  delay: 1500,
  timeout: 10000,
});

const fillFinanceTable = Loadable({
  loader: () => import("./WebAddinWriter/WriteComponents/pages/fillFinanceTable"),
  loading: loadingComponent,
  delay: 1500,
  timeout: 10000,
});


export const WebAddinTemplate = Loadable({
  loader: () => import("./WebAddinCompose/WebAddinTemplate"),
  loading: loadingComponent,
  delay: 1500,
  timeout: 10000,
});

export const WebAddinTplDetail = Loadable({
  loader: () => import("./WebAddinCompose/WebAddinTplDetail"),
  loading: loadingComponent,
  delay: 1500,
  timeout: 10000,
});
export const WebAddinGenTpl = Loadable({
  loader: () => import("./WebAddinCompose/WebAddinGenTpl"),
  loading: loadingComponent,
  delay: 1500,
  timeout: 10000,
});

/*
const WebAddinOtherFun = Loadable({
    loader: () => import("./WebAddinOtherFun"),
    loading: loadingComponent,
    delay: 1500,
    timeout: 10000
});

const WebAddinUserCenter = Loadable({
    loader: () => import("./WebAddinUserCenter"),
    loading: loadingComponent,
    delay: 1500,
    timeout: 10000
});

const WebAddinReglogin = Loadable({
    loader: () => import("./WebAddinReglogin"),
    loading: loadingComponent,
    delay: 1500,
    timeout: 10000
});

const WebAddinFindPsw = Loadable({
    loader: () => import("./WebAddinFindPsw"),
    loading: loadingComponent,
    delay: 1500,
    timeout: 10000
});

const MoblieResetPsw = Loadable({
    loader: () => import("./WebAddinResetPsw"),
    loading: loadingComponent,
    delay: 1500,
    timeout: 10000
});
*/
function isPoneAvailable(poneInput) {
  if (!/^1[3456789]\d{9}$/.test(poneInput)) {
    return false;
  } else {
    return true;
  }
}
function isEmail(str) {
  var re = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
  if (re.test(str) !== true) {
    return false;
  } else {
    return true;
  }
}
/*
function isValidReg(chars) {
  var re = /<|>|\[|\]|\{|\}|『|』|※|○|●|◎|§|△|▲|☆|★|◇|◆|□|▼|㊣|﹋|⊕|⊙|〒|ㄅ|ㄆ|ㄇ|ㄈ|ㄉ|ㄊ|ㄋ|ㄌ|ㄍ|ㄎ|ㄏ|ㄐ|ㄑ|ㄒ|ㄓ|ㄔ|ㄕ|ㄖ|ㄗ|ㄘ|ㄙ|ㄚ|ㄛ|ㄜ|ㄝ|ㄞ|ㄟ|ㄢ|ㄣ|ㄤ|ㄥ|ㄦ|ㄧ|ㄨ|ㄩ|■|▄|▆|\*|@|#|\^|\\/;
  if (re.test(chars) === true) {
    return false;
  } else {
    return true;
  }
}
 */
//对字符串进行加密
function compileStr(code) {
  var c = String.fromCharCode(code.charCodeAt(0) + code.length);
  for (var i = 1; i < code.length; i++) {
    c += String.fromCharCode(code.charCodeAt(i) + code.charCodeAt(i - 1));
  }
  return escape(c);
} 
function isValidInf(userInf, checkEmail) {
  //console.log("(userInf  ", userInf);
  //console.log("(userInf ).length", (userInf["code"] + "").length);
  if ((userInf["code"] + "").length < 4) {
    return "验证码错误";
  }
  if (checkEmail === true) {
    console.log("userInf[email]:", userInf["email"]);
    if (isEmail(userInf["email"]) === false) {
      return "邮箱格式不合法";
    }
  }
  if (isPoneAvailable(userInf["phone"]) === false) {
    return "手机格式不合法";
  }
  if ((userInf["psw"] + "").length < 6) {
    return "密码长度不够或者不合法";
  }
  return true;
}

// function Str2Uint16(str){
//   //假设字符串”abc“ length=3,使用16位，则每一个字母占据2字节，总字节为length乘以2
//   var arraybuffer =new ArrayBuffer(str.length*2);
//   var view = new Uint16Array(arraybuffer);
//   for(var i=0,l=str.length;i<l;i++){
//       view[i] = str.charCodeAt(i);
//   }
//   return view;
// }   

// function Str2Uint8(str){
//   //假设字符串”abc“ length=3,使用16位，则每一个字母占据2字节，总字节为length乘以2
//   var arraybuffer =new ArrayBuffer(str.length);
//   var view = new Uint8Array(arraybuffer);
//   for(var i=0,l=str.length;i<l;i++){
//       view[i] = str.charCodeAt(i);
//   }
//   return view;
// }    
 
// export function readwrite() {

//     let data = wps.FileSystem.readAsBinaryString("d:\\1.docx")
//     //let file = new window.File([blob], "no_fileName", {type: blob.type})
// //     var link = document.createElement("a"); // Or maybe get it from the current document
// // link.href = blob;
// // link.download = "aDefaultFileName.docx";
// // link.innerHTML = "Click here to download the file";
// // document.body.appendChild(link); // Or append it whereever you wan
//    let buffer = Buffer.from(data);
//    console.log("data.length:",data.length);
//    console.log("buffer:",buffer.buffer);
//    var blob = new Blob([Str2Uint8(data)], {
//     type: 'application/octet-stream'
//     });
//     let file = new window.File([blob], "lite.docx", {type: blob.type})
//     //wps.alert("blob.size"+file.size);
//     console.log("file:",file); 
//     console.log("msSaveOrOpenBlob:",navigator); 
//     //wps.FileSystem.writeAsBinaryString("d:\\2.docx",data)
//   let newName= "d:\\2.docx"

//   var reader = new FileReader();
//   reader.readAsBinaryString(blob);
//   reader.onload = function(){
//       //读取完毕后输出结果
//      // console.log(this.result);
//       wps.FileSystem.writeAsBinaryString(newName,this.result);
//       console.log("this.result");
//   }
  
//   if (navigator.msSaveOrOpenBlob) {
    
//     navigator.msSaveOrOpenBlob(blob, newName);
    
//   } else {
//     let temp_link = document.createElement('a');
//     let evt = document.createEvent("HTMLEvents");
//     evt.initEvent("click", true, true); //initEvent 不加后两个参数在FF下会报错  事件类型，是否冒泡，是否阻止浏览器的默认行为
//     temp_link.href = URL.createObjectURL(blob);
//     temp_link.download = newName;
//     temp_link.type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
//     document.body.appendChild(temp_link);
//     temp_link.click();
//     temp_link.remove();
//   }

// }
export function arrayBufferToBase64(buffer) {
  let binary = "";
  let bytes = new Uint8Array(buffer);
  let len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}
class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
    }
   // readwrite();
    console.log("init ribbon")
    window.ribbon = ribbon;
   
  }
  componentDidMount() {
    //读cookie登陆,发现没有登录时才启动
    //console.log(this.props.current.user_id );
    handleFetch(`${apiPublicPath}users/reglogin/index`, { method: "GET" }).then((res) => {
      if (res !==undefined && res.success === true) {
        this.setState({ curUser: res, hideSignDlg: true, hideEmail: true });
        // this.props.getCookie(res);
      } else {
        this.setState({ curUser: { user_id: "" } });
      }
    });
  }
  state = {
    curUser: { user_id: "" },
    hideSignDlg: true,
    hideEmail: false,
  };

  regLogin = (userInf, checkEmail) => {
    const checkInf = isValidInf(userInf, checkEmail);
    if (isValidInf(userInf, checkEmail) === true) {
      let encryptedValues = {};
      var pswmd = md5.hex(userInf["psw"] + md5.hex(userInf["psw"]));
      const telphone = userInf["phone"].replace(/\s+/g, "");
      const captcha = userInf["code"].replace(/\s+/g, "");
      const email = userInf["email"].replace(/\s+/g, "");

      //Cookies.set("email", email, { expires: 365 });//deviceid    email: email+"",
      encryptedValues.tel = telphone + "";
      encryptedValues.password = pswmd + "";
      encryptedValues.captcha = captcha + "";
      encryptedValues.email = email + "";

      if (checkEmail === true) {
        //注册
        const loginRes = `${apiPublicPath}users/reglogin/register`;
        //console.log(" JSON.stringify(encryptedValues):",  JSON.stringify(encryptedValues));
        handlePost(loginRes, encryptedValues).then((result) => {
          try {
            if (result.success === true) {
              this.setState({ curUser: result, hideSignDlg: true, hideEmail: true });
              //console.log("this.state.curUser:", this.state.curUser);
              //写入本地cookie
              Cookies.set("phone", compileStr(telphone), { expires: 365 });
              Cookies.set("email", compileStr(email), { expires: 365 });
              Cookies.set("pswen", compileStr(userInf["psw"]), { expires: 365 });
            } else {
              DialogAlert.success({
                title: "注册错误",
                content: result.msg,
                time: 2000,
              });
              document.getElementById("captchain").src = `${apiPublicPath}tools/codepic?` + Math.random();
            }
          } catch (e) {
            DialogAlert.success({
              title: "注册错误",
              content: "数据获取错误，请检查网络！",
              time: 2000,
            });
          }
        });
      } else {
        //登录{"tel": "13886186111", "password": "338cedb8182d67647893fea981e3ffac", "deviceid": "husteducntestjames"}
        const loginRes = `${apiPublicPath}users/reglogin/login`;
        //console.log(" JSON.stringify(encryptedValues):",  JSON.stringify(encryptedValues));
        handlePost(loginRes, encryptedValues).then((result) => {
          try {
            if (result.success === true) {
              this.setState({ curUser: result, hideSignDlg: true, hideEmail: true });
              //console.log("this.state.curUser:", this.state.curUser);
              //写入本地cookie
              Cookies.set("phone", compileStr(telphone), { expires: 365 });
              Cookies.set("email", compileStr(email), { expires: 365 });
              Cookies.set("pswen", compileStr(userInf["psw"]), { expires: 365 });
            } else {
              DialogAlert.success({
                title: "登录错误",
                content: result.msg,
                time: 2000,
              });
              document.getElementById("captchain").src = `${apiPublicPath}tools/codepic?` + Math.random();
            }
          } catch (e) {
            //console.log(e);
            // message.error("数据获取错误，请检查网络！");
            DialogAlert.success({
              title: "登录错误",
              content: "数据获取错误，请检查网络！",
              time: 2000,
            });
          }
        });
      }
    } else {
      //显示提示信息
      //alert(checkInf);
      //console.log("userInf:", userInf);
      DialogAlert.success({
        title: "输入错误",
        content: checkInf,
        time: 2000,
      });
    }
  };

  logoutHandler = (e) => {
    handlePost(`${apiPublicPath}users/reglogin/logout`, {}).then((result) => {
      // this.props.history.push("/");
      this.setState({ curUser: { user_id: "" }, hideSignDlg: false, hideEmail: true });
      //console.log("logout_ok:",this.state)
    });
  };

  loginHandler = (userInf, e) => {
    this.regLogin(userInf, false);
  };
  signHandler = (userInf, e) => {
    this.regLogin(userInf, true);
  };
  signShowHandler = (e) => {
    this.setState({ hideSignDlg: false });
  };
  signHideHandler = (e) => {
    this.setState({ hideSignDlg: true });
  };
  selectData = (e) => {
    this.setState({ SelectID: e });
    console.log("selectData_e",e);
  };
  render() {
     //如果在浏览器打开网页，那么会显示下面内容
    return (
      <div className="App">
        <Provider
          value={{
            state: this.state,
            onLogout: this.logoutHandler,
            onLogin: this.loginHandler,
            showSignUp: this.signShowHandler,
            hideSignUp: this.signHideHandler,
            signUp: this.signHandler,
            selectData:this.selectData,
          }}
        >
          <Router>
            <Switch>
              <Route exact path="/" component={TaskHome} />
              <Route path="/DemoVideo" component={WebAddinDemoVideo} />
              <Route path="/AboutUs" component={WebAddinAboutUs} />
              <Route path="/Compose" component={WebAddinCompose} />
              <Route path="/Writer" component={WebAddinWriter} />
              <Route path="/fillFinanceTable" component={fillFinanceTable} />
              <Route render={() => <Redirect to="/" />} />
            </Switch>
          </Router>
          <WebAddinSignInOut />
        </Provider>
       
      </div>
    );
  }
}
export default App;
