//import { Button } from 'antd';
import React, { Component } from 'react';
//import FootNav from '../../navigator/navigator';
//import Btn from '../../buttons';
import './index.css'
import Logo from '../../logo/logo';
class Two extends Component {

    render() {
        return (
            <div >
                {/* 列表
                <br />
                <Btn text="插入图片" />
                <Btn text="插入表格" />
                <Btn text="插入文本" /> */}
                <Logo />
            </div>
        )
    }
}

export default Two;