module.exports = {
  publicPath: '/',
  apiPublicPath: '/api/',
  apiWritePath: '/vstoapi/',
  RootPath: 'https://www.aidocx.com/',
};
