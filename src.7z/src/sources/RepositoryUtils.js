import Tree from "rc-tree";

export function GetRealData(response) {
  //获得实际数据
  if (response["success"]) {
    if (response["head"] == null) {
      if (response["msg"] == null) {
        return "";
      } else {
        return response["msg"];
      }
    } else {
      return '{"head":' + response["head"] + ',"data":' + response["msg"] + "}";
    }
  } else {
    return "";
  }
}

export function GetRealDataOfYear(response) {
  //获得实际数据
  if (response["success"]) {
    if (response["head"] != null) {
      if (response["msg"] == null) {
        return "";
      } else {
        return response["msg"];
      }
    } else {
      return '{"head":' + response["head"] + ',"data":' + response["msg"] + "}";
    }
  } else {
    return "";
  }
}

export function GetRealDataOfFinance(response) {
  //获得实际数据
  if (response["success"]) {
    if (response["head"] == null) {
      if (response["msg"] == null) {
        return "";
      } else {
        return response["msg"];
      }
    } else {
      return '{"head":' + response["head"] + ',"data":' + response["msg"] + "}";
    }
  } else {
    return "";
  }
}

function JsonToTree(JsonStr) {
  //将json转换为antidesign tree控件的数据源
  //思路：便利重建
  //https://blog.csdn.net/xujie3/article/details/52954940
  var JsonObj = JSON.parse(JsonStr);
  var tmpJson = {};
  for (var p in JsonObj) {
    //遍历json数组时
    //从p中读取详细信息
    let title = p.substring(p.indexOf("_") + 1);
    tmpJson.title = title.substring(0, title.lastIndexOf(":"));
    tmpJson.key = title.substring(title.lastIndexOf(":") + 1);
    let subJson = [];
    //var subObj = JSON.parse(JsonObj[p]);
    //console.log("subObj:", subObj);
    //console.log("JsonObj[p]:",JsonObj[p])
    Object.keys(JsonObj[p]).forEach(function(key){

      //console.log(key,JsonObj[p][key]);
 
     });
    for (var s in JsonObj[p]) {
      let lastJson = {};
      
      if ( JsonObj[p][s] !==""){
        console.log("JSON.stringify(JsonObj[p][s]):",  JSON.stringify(JsonObj[p][s]));
        console.log("subJson :",    JsonToTree(JSON.stringify(JsonObj[p][s])));
        //subJson.children= JsonToTree(JSON.stringify(JsonObj[p][s])) ;
        lastJson= JsonToTree(JSON.stringify(JsonObj[p][s]))
        
     }else{
      
      let title = s.substring(s.indexOf("_") + 1);
      lastJson.title = title.substring(0, title.lastIndexOf(":"));
      lastJson.key = title.substring(title.lastIndexOf(":") + 1);
     }
     subJson.push(lastJson);
    }
    tmpJson.children = subJson;
   // console.log("tmpJson:", tmpJson);
  }
  return tmpJson;
}

export function ConvertJsonToTree(jsonArray) {
  //将json转换为antidesign tree控件的数据源，要用到递归
  var TreeJson = [];
  for (var a in jsonArray) {
    //遍历json数组时，这么写p为索引，0,1
    //console.log(a);
    console.log("JsonStr:", jsonArray[a]["文本元结构"]);
    TreeJson.push(JsonToTree(jsonArray[a]["文本元结构"]));
  }
  console.log("TreeJson:", TreeJson);
  return TreeJson;
}

export function ConvertJsonToTreeOfYear(jsonArray) {
  //将json转换为antidesign tree控件的数据源，要用到递归
  var TreeJson = [];
  for (var a in jsonArray) {
    //遍历json数组时，这么写p为索引，0,1
    console.log(a);
    console.log("JsonStr:", jsonArray[a]);
    let lastJson = {};
    lastJson.title = jsonArray[a]["年份"];
    lastJson.key = a;
    TreeJson.push(lastJson);
  }
  console.log("TreeJson:", TreeJson);
  return TreeJson;
}

export function ConvertJsonToTreeOfFinance(jsonArray) {
  //将json转换为antidesign tree控件的数据源，要用到递归
  var TreeJson = [];
  var numOfFinance = [];
  var TreeAndNumber = [];

  var p = 0;
  for (var a in jsonArray) {
    if (a == "财报ID" || a == "公司ID") {
      console.log("hhhhh");
    } else {
      console.log(jsonArray["" + a]);
      console.log("JsonStr:", a);
      let lastJson = {};
      let lastNum = {};
      lastJson.title = a;
      lastJson.key = p;
      lastNum.key = p;
      lastNum.value = jsonArray["" + a];
      TreeJson.push(lastJson);
      numOfFinance.push(lastNum);
      p++;
    }
  }
  TreeAndNumber.push(TreeJson);
  TreeAndNumber.push(numOfFinance);
  console.log("numOfFinance", numOfFinance);
  console.log("TreeJson:", TreeJson);
  console.log(TreeAndNumber);
  return TreeAndNumber;
}
