import React from 'react';
import ReactDOM from 'react-dom';
//import { HashRouter, Route, Switch } from 'react-router-dom';
import App from './components/App';
// import Dialog from './components/dialog';
// import TaskPane from './components/taskpane';

import { AppContainer } from "react-hot-loader"; 
// redux参考：https://www.jianshu.com/p/21960f78937d
// 导航条参考：https://developer.microsoft.com/en-us/fabric-js/components/commandbar/commandbar
const title = "筷子文档"//"Intelligent Composing";

ReactDOM.render(

  <AppContainer>
    <App title={title}  />
  </AppContainer>,

document.getElementById("root")
);


