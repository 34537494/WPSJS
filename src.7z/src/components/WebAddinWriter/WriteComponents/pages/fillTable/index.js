import React, { Component } from 'react';
 
import FillTable from '../../fillTable/fillTable';
 

class Fill extends Component {
    render() {
        return (
            <div>
                <FillTable />
            </div>
        )
    }
}

export default Fill;