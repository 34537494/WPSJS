/* eslint-disable jsx-a11y/alt-text */
//浮动窗口
import * as React from "react";
import { Dialog, DialogType, DialogFooter } from "office-ui-fabric-react";
import { PrimaryButton, DefaultButton, ActionButton } from "office-ui-fabric-react";
//import { ContextualMenu } from "office-ui-fabric-react/lib/ContextualMenu";
//import { Label } from 'office-ui-fabric-react/lib/Label';
import { TextField } from "office-ui-fabric-react";
//import { getId } from 'office-ui-fabric-react/lib/Utilities';
import { apiPublicPath, RootPath } from "../../settings";
import { Consumer } from "../WebAddinContext";
//import { Stack } from "office-ui-fabric-react/lib/Stack";
import { Link } from "office-ui-fabric-react";
const Cookies = require("js-cookie"); //登录过就不要再注册了
let signInf = [];
//字符串进行解密
function uncompileStr(code) {
  code = unescape(code);
  var c = String.fromCharCode(code.charCodeAt(0) - code.length);
  for (var i = 1; i < code.length; i++) {
    c += String.fromCharCode(code.charCodeAt(i) - c.charCodeAt(i - 1));
  }
  return c;
}
 
export default class WebAddinSignInOut extends React.Component {
  constructor(props) {
    super(props);
    signInf["phone"] = uncompileStr(Cookies.get("phone"));
    signInf["psw"] =  uncompileStr(Cookies.get("pswen"));
    signInf["email"] = uncompileStr(Cookies.get("email"));
    signInf["code"] ="";
  }
  _dragOptions = {
    moveMenuItemText: "移动",
    closeMenuItemText: "关闭",
    //menu: ContextualMenu
  };

  handleChangePhone = (e, value) => {
    //console.log("sign_up_change_e:",e);
    //console.log("sign_up_change_value:",value);
    signInf["phone"] = value;
    //console.log("this.state:",this.state)
  };

  handleChangePsw = (e, value) => {
    //console.log("sign_up_change_e:",e);
    //console.log("sign_up_change_value:",value);
    signInf["psw"] = value;
  };

  handleChangeCode = (e, value) => {
    signInf["code"] = value;
  };
  handleCodeKeypress = (action, sign, e) => {
    //console.log("handleCodeKeypress_handleCodeKeypress_action:",action);
    //console.log("handleCodeKeypress_handleCodeKeypress_sign:",sign);
    //console.log("handleCodeKeypress_handleCodeKeypress_e:",e);
    if (e.key === "Enter") {
      action(sign);
    }
  };
  handleEmailKeypress = (action, sign, e) => {
    //console.log("EmailKeypress_handleCodeKeypress_action:",action);
    //console.log("EmailKeypress_handleCodeKeypress_sign:",sign);
    //console.log("EmailKeypress_handleCodeKeypress_e:",e);
    if (e.key === "Enter") {
      action(sign);
    }
  };

  handleChangeEmail = (e, value) => {
    signInf["email"] = value;
  };

  render() {
    return (
      <Consumer>
        {({ state, hideSignUp, signUp, onLogin }) => (
          <Dialog
            hidden={state.hideSignDlg}
            onDismiss={hideSignUp}
            dialogContentProps={{
              type: DialogType.normal,
              closeButtonAriaLabel: "关闭",
              title: "注册登录",
            }}
            modalProps={{
              isBlocking: false,
              styles: { main: { maxWidth: 450 } },
              dragOptions: this._dragOptions,
            }}
          >
            <TextField
              label="手机号"
              onChange={this.handleChangePhone}
              onKeyPress={this.handleEmailKeypress.bind(this, onLogin, signInf)}
              required
            />

            <TextField
              label="密码"
              type="password"
              onChange={this.handleChangePsw}
              onKeyPress={this.handleEmailKeypress.bind(this, onLogin, signInf)}
              required
            />
            <div className="piccode">
              <div style={{ display: "flex", width: "90px" }}>
                <TextField
                  label="验证码"
                  styles={{ fieldGroup: { width: 100 } }}
                  onChange={this.handleChangeCode}
                  onKeyPress={this.handleCodeKeypress.bind(this, onLogin, signInf)}
                  required
                />
              </div>

              <img
                style={{ cursor: "pointer" }}
               // className={styles["changeinImg"]}
                onClick={() =>
                  (document.getElementById("captchain").src = `${apiPublicPath}tools/codepic?` + Math.random())
                }
                id="captchain"
                className="captchain"
                src={`${apiPublicPath}tools/codepic`}
              />
            </div>

            <div hidden={!!state.hideEmail}>
              <TextField
                label="Email"
                onChange={this.handleChangeEmail}
                onKeyPress={this.handleEmailKeypress(this, signUp, signInf)}
              />
            </div>
            <DialogFooter>
              <Link href={RootPath + "FindPsw"}>
                <ActionButton iconProps={{ iconName: "ProtectRestrict" }} allowDisabledFocus></ActionButton>
              </Link>
              <PrimaryButton onClick={onLogin.bind(this, signInf)} text="登录" />
              <DefaultButton onClick={signUp.bind(this, signInf)} text="注册" />
            </DialogFooter>
          </Dialog>
        )}
      </Consumer>
    );
  }
}
